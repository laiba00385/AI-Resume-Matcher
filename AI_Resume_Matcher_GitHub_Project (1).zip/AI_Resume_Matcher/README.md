# AI Resume Matcher 🤖

A beginner-friendly NLP project that compares a resume with a job description and estimates how closely their wording matches.

## Features
- Upload a `.txt` resume or paste resume text.
- Paste a job description.
- Calculate a similarity score using **TF-IDF** and **cosine similarity**.
- Show words found in both texts and possible missing keywords.
- Simple web interface built with Streamlit.

## Tech stack
- Python
- Streamlit
- scikit-learn
- Natural Language Processing (NLP)

## Run locally

1. Install Python 3.10 or newer.
2. Download or clone this repository.
3. Open a terminal in the project folder.
4. Install dependencies:

```bash
pip install -r requirements.txt
```

5. Start the app:

```bash
streamlit run app.py
```

The app will open in your browser.

## How it works
1. The app cleans and normalizes the text.
2. TF-IDF converts both texts into numerical vectors.
3. Cosine similarity compares the vectors and returns a percentage.
4. A simple keyword comparison highlights overlapping and potentially missing words.

## Important limitation
The percentage is a text-similarity estimate, **not** a measure of a person's ability or suitability. It may miss synonyms and context. Do not use it as the only basis for hiring decisions.

## Future improvements
- Support PDF and DOCX resumes.
- Add synonym and semantic similarity support using sentence embeddings.
- Export an analysis report.
- Add multilingual resume support.

## Author
Add your name and GitHub profile here.
