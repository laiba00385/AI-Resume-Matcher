import streamlit as st
import re
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

st.set_page_config(page_title="AI Resume Matcher", page_icon="🤖", layout="centered")

st.title("🤖 AI Resume Matcher")
st.write("Upload or paste a resume and compare it with a job description using NLP.")
st.caption("This demo uses TF-IDF and cosine similarity. It is a learning tool, not a hiring decision system.")

resume_file = st.file_uploader("Upload your resume (.txt)", type=["txt"])
resume_text = ""
if resume_file:
    resume_text = resume_file.getvalue().decode("utf-8", errors="ignore")

resume_text = st.text_area("Or paste your resume here", value=resume_text, height=220,
                           placeholder="Paste your skills, education, and experience...")

job_text = st.text_area("Paste the job description", height=220,
                        placeholder="Paste the job requirements and responsibilities...")

def clean_text(text):
    text = text.lower()
    text = re.sub(r"[^a-z0-9+#.\s]", " ", text)
    return re.sub(r"\s+", " ", text).strip()

if st.button("Analyze Match", type="primary", use_container_width=True):
    if not resume_text.strip() or not job_text.strip():
        st.warning("Please provide both a resume and a job description.")
    else:
        documents = [clean_text(resume_text), clean_text(job_text)]
        vectorizer = TfidfVectorizer(stop_words="english")
        matrix = vectorizer.fit_transform(documents)
        score = cosine_similarity(matrix[0:1], matrix[1:2])[0][0] * 100

        st.subheader("Match result")
        st.metric("Resume-to-job similarity", f"{score:.1f}%")
        st.progress(int(round(score)))

        resume_words = set(documents[0].split())
        job_words = set(documents[1].split())
        keywords = sorted(word for word in (job_words - resume_words)
                          if len(word) > 2 and word not in {"the", "and", "with", "for", "you", "are"})
        matched = sorted(word for word in (job_words & resume_words)
                         if len(word) > 2 and word not in {"the", "and", "with", "for", "you", "are"})

        left, right = st.columns(2)
        with left:
            st.markdown("**Relevant words found**")
            st.write(", ".join(matched[:30]) if matched else "No clear keyword overlap found.")
        with right:
            st.markdown("**Possible missing keywords**")
            st.write(", ".join(keywords[:30]) if keywords else "No obvious missing keywords found.")

        st.info("Tip: If a missing keyword genuinely matches your experience, consider adding it naturally to your resume. Never add skills you do not have.")

st.divider()
st.caption("Built with Python, Streamlit, scikit-learn, and basic Natural Language Processing.")
